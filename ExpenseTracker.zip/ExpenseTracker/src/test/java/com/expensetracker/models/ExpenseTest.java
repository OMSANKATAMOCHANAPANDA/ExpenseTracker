package com.expensetracker.models;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

public class ExpenseTest {
    @Test
    public void testExpenseConstructor() {
        LocalDate testDate = LocalDate.of(2023, 1, 15);
        Expense expense = new Expense(150.75, 2, testDate, "Groceries");

        assertEquals(150.75, expense.getAmount(), 0.001);
        assertEquals(2, expense.getCategoryId());
        assertEquals(testDate, expense.getDate());
        assertEquals("Groceries", expense.getDescription());
    }

    @Test
    public void testSettersAndGetters() {
        Expense expense = new Expense();
        LocalDate testDate = LocalDate.now();

        expense.setAmount(99.99);
        expense.setCategoryId(3);
        expense.setDate(testDate);
        expense.setDescription("Test Description");

        assertEquals(99.99, expense.getAmount(), 0.001);
        assertEquals(3, expense.getCategoryId());
        assertEquals(testDate, expense.getDate());
        assertEquals("Test Description", expense.getDescription());
    }

    @Test
    public void testEqualsAndHashCode() {
        LocalDate date1 = LocalDate.of(2023, 1, 1);
        LocalDate date2 = LocalDate.of(2023, 1, 2);

        Expense expense1 = new Expense(100.0, 1, date1, "Food");
        Expense expense2 = new Expense(100.0, 1, date1, "Food");
        Expense expense3 = new Expense(200.0, 2, date2, "Transport");

        assertEquals(expense1, expense2);
        assertNotEquals(expense1, expense3);
        assertEquals(expense1.hashCode(), expense2.hashCode());
    }

    @Test
    public void testToString() {
        Expense expense = new Expense(50.0, 1, LocalDate.of(2023, 1, 15), "Lunch");
        String expected = "Expense{amount=50.0, categoryId=1, date=2023-01-15, description=Lunch}";
        assertEquals(expected, expense.toString());
    }
}
