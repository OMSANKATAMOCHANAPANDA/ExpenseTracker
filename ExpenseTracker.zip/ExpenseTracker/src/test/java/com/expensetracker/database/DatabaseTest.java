package com.expensetracker.database;

import org.junit.jupiter.api.*;
import java.sql.Connection;
import java.sql.Statement;
import static org.junit.jupiter.api.Assertions.*;

public class DatabaseTest {
    private Connection connection;

    @BeforeEach
    public void setUp() throws Exception {
        // Initialize test database
        connection = DatabaseManager.getConnection();

        // Create test tables
        try (Statement stmt = connection.createStatement()) {
            stmt.execute("CREATE TABLE IF NOT EXISTS categories (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT NOT NULL UNIQUE, " +
                    "budget_limit REAL DEFAULT 0.0)");

            stmt.execute("CREATE TABLE IF NOT EXISTS expenses (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "amount REAL NOT NULL, " +
                    "category_id INTEGER NOT NULL, " +
                    "date TEXT NOT NULL, " +
                    "description TEXT, " +
                    "FOREIGN KEY (category_id) REFERENCES categories(id))");

            // Clear any existing test data
            stmt.execute("DELETE FROM expenses");
            stmt.execute("DELETE FROM categories");
        }
    }

    @AfterEach
    public void tearDown() throws Exception {
        // Clean up
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    @Test
    public void testDatabaseConnection() throws Exception {
        assertNotNull(connection);
        assertFalse(connection.isClosed());
    }

    @Test
    public void testTableCreation() throws Exception {
        try (Statement stmt = connection.createStatement()) {
            // Test categories table exists
            assertTrue(stmt.execute("SELECT 1 FROM categories LIMIT 1"));

            // Test expenses table exists
            assertTrue(stmt.execute("SELECT 1 FROM expenses LIMIT 1"));
        }
    }

    @Test
    public void testForeignKeyConstraint() throws Exception {
        try (Statement stmt = connection.createStatement()) {
            // Should fail due to foreign key constraint
            Exception exception = assertThrows(Exception.class, () -> {
                stmt.execute("INSERT INTO expenses (amount, category_id, date) " +
                        "VALUES (100.0, 999, '2023-01-01')");
            });

            assertTrue(exception.getMessage().contains("FOREIGN KEY constraint failed"));
        }
    }
}
