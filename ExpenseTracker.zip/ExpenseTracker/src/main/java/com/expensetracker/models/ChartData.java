// CategoryDAO.java
package com.expensetracker.database;

import com.expensetracker.models.Category;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryDAO {
    public List<Category> getAllCategories() throws SQLException {
        String sql = "SELECT id, name, budget_limit FROM categories ORDER BY name";
        List<Category> categories = new ArrayList<>();

        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Category category = new Category();
                category.setId(rs.getInt("id"));
                category.setName(rs.getString("name"));
                category.setBudgetLimit(rs.getDouble("budget_limit"));
                categories.add(category);
            }
        }

        return categories;
    }

    public void addCategory(Category category) throws SQLException {
        String sql = "INSERT INTO categories (name, budget_limit) VALUES (?, ?)";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, category.getName());
            pstmt.setDouble(2, category.getBudgetLimit());
            pstmt.executeUpdate();
        }
    }
}
