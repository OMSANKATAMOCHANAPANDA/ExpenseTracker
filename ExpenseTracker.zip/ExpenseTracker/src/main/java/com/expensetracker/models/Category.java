// Category.java
package com.expensetracker.models;

public class Category {
    private int id;
    private String name;
    private double budgetLimit;

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getBudgetLimit() { return budgetLimit; }
    public void setBudgetLimit(double budgetLimit) { this.budgetLimit = budgetLimit; }

    @Override
    public String toString() {
        return name;
    }
}
