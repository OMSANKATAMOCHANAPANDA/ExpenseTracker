// ChartGenerator.java
package com.expensetracker.utils;

import com.expensetracker.database.ExpenseDAO;
import com.expensetracker.models.ChartData;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ChartGenerator {
    public static void generateMonthlyBarChart(BarChart<String, Number> chart,
                                               LocalDate startDate, LocalDate endDate) {
        try {
            ExpenseDAO dao = new ExpenseDAO();
            List<ChartData> chartData = dao.getMonthlyExpenses(startDate, endDate);

            chart.getData().clear();
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Monthly Expenses");

            for (ChartData data : chartData) {
                series.getData().add(new XYChart.Data<>(data.getName(), data.getValue()));
            }

            chart.getData().add(series);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void generateCategoryPieChart(PieChart chart,
                                                LocalDate startDate, LocalDate endDate) {
        try {
            ExpenseDAO dao = new ExpenseDAO();
            List<ChartData> chartData = dao.getCategoryExpenses(startDate, endDate);

            chart.getData().clear();
            for (ChartData data : chartData) {
                chart.getData().add(new PieChart.Data(data.getName(), data.getValue()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
