// CSVExporter.java
package com.expensetracker.utils;

import com.expensetracker.database.ExpenseDAO;
import com.expensetracker.models.Expense;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

public class CSVExporter {
    public static void exportReport(String reportType, LocalDate startDate,
                                    LocalDate endDate, String filePath) throws Exception {
        ExpenseDAO expenseDAO = new ExpenseDAO();
        List<Expense> expenses = expenseDAO.getExpensesByDateRange(startDate, endDate);

        try (FileWriter writer = new FileWriter(filePath)) {
            switch (reportType) {
                case "Detailed Expenses":
                    exportDetailedExpenses(writer, expenses, startDate, endDate);
                    break;
                case "Category Summary":
                    exportCategorySummary(writer, expenses, startDate, endDate);
                    break;
                case "Monthly Summary":
                    exportMonthlySummary(writer, expenses, startDate, endDate);
                    break;
            }
        }
    }

    private static void exportDetailedExpenses(FileWriter writer, List<Expense> expenses,
                                               LocalDate startDate, LocalDate endDate) throws IOException {
        writer.append("Expense Report\n");
        writer.append("Date Range,").append(startDate.toString()).append(" to ").append(endDate.toString()).append("\n");
        writer.append("Date,Amount,Category,Description\n");

        for (Expense expense : expenses) {
            writer.append(expense.getDate().toString()).append(",")
                    .append(String.valueOf(expense.getAmount())).append(",")
                    .append(expense.getCategoryName()).append(",")
                    .append(expense.getDescription() != null ? expense.getDescription() : "").append("\n");
        }

        double total = expenses.stream().mapToDouble(Expense::getAmount).sum();
        writer.append("\nTotal Expenses,$").append(String.valueOf(total));
    }
}
