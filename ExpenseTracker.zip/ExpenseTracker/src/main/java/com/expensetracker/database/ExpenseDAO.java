// ExpenseDAO.java
package com.expensetracker.database;

import com.expensetracker.models.Expense;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ExpenseDAO {
    public void addExpense(Expense expense) throws SQLException {
        String sql = "INSERT INTO expenses (amount, category_id, date, description) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDouble(1, expense.getAmount());
            pstmt.setInt(2, expense.getCategoryId());
            pstmt.setString(3, expense.getDate().toString());
            pstmt.setString(4, expense.getDescription());
            pstmt.executeUpdate();
        }
    }

    public List<Expense> getExpensesByDateRange(LocalDate start, LocalDate end) throws SQLException {
        String sql = "SELECT e.id, e.amount, e.category_id, c.name as category_name, e.date, e.description " +
                "FROM expenses e JOIN categories c ON e.category_id = c.id " +
                "WHERE date BETWEEN ? AND ? ORDER BY date DESC";
        List<Expense> expenses = new ArrayList<>();

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, start.toString());
            pstmt.setString(2, end.toString());

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Expense expense = new Expense();
                expense.setId(rs.getInt("id"));
                expense.setAmount(rs.getDouble("amount"));
                expense.setCategoryId(rs.getInt("category_id"));
                expense.setCategoryName(rs.getString("category_name"));
                expense.setDate(LocalDate.parse(rs.getString("date")));
                expense.setDescription(rs.getString("description"));
                expenses.add(expense);
            }
        }

        return expenses;
    }
}
