// DatabaseInitializer.java
package com.expensetracker.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInitializer {
    public static void initialize() {
        String createCategoriesTable = """
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                budget_limit REAL DEFAULT 0.0
            )""";

        String createExpensesTable = """
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount REAL NOT NULL,
                category_id INTEGER NOT NULL,
                date TEXT NOT NULL,
                description TEXT,
                FOREIGN KEY (category_id) REFERENCES categories(id)
            )""";

        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(createCategoriesTable);
            stmt.execute(createExpensesTable);

            // Insert default categories if none exist
            insertDefaultCategories(conn);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void insertDefaultCategories(Connection conn) throws SQLException {
        String checkCategories = "SELECT COUNT(*) FROM categories";
        try (PreparedStatement pstmt = conn.prepareStatement(checkCategories)) {
            var rs = pstmt.executeQuery();
            if (rs.getInt(1) == 0) {
                String[] defaultCategories = {"Food", "Transport", "Housing", "Entertainment", "Utilities"};
                String insertSQL = "INSERT INTO categories (name) VALUES (?)";
                try (PreparedStatement insertStmt = conn.prepareStatement(insertSQL)) {
                    for (String category : defaultCategories) {
                        insertStmt.setString(1, category);
                        insertStmt.executeUpdate();
                    }
                }
            }
        }
    }
}
