// ReportController.java
package com.expensetracker.controllers;

import com.expensetracker.database.ExpenseDAO;
import com.expensetracker.utils.CSVExporter;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import java.io.File;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;

public class ReportController {
    @FXML private DatePicker startDatePicker;
    @FXML private DatePicker endDatePicker;
    @FXML private ComboBox<String> reportTypeComboBox;
    @FXML private TextArea reportOutput;
    @FXML private Button generateButton;
    @FXML private Button exportButton;

    private final ExpenseDAO expenseDAO = new ExpenseDAO();

    public void initialize() {
        // Set default date range to current month
        YearMonth currentMonth = YearMonth.now();
        startDatePicker.setValue(currentMonth.atDay(1));
        endDatePicker.setValue(currentMonth.atEndOfMonth());

        reportTypeComboBox.getItems().addAll(
                "Detailed Expenses",
                "Category Summary",
                "Monthly Summary"
        );
        reportTypeComboBox.getSelectionModel().select(0);
    }

    @FXML
    private void handleGenerateReport() {
        LocalDate startDate = startDatePicker.getValue();
        LocalDate endDate = endDatePicker.getValue();
        String reportType = reportTypeComboBox.getValue();

        try {
            String report = "";
            switch (reportType) {
                case "Detailed Expenses":
                    report = generateDetailedReport(startDate, endDate);
                    break;
                case "Category Summary":
                    report = generateCategorySummary(startDate, endDate);
                    break;
                case "Monthly Summary":
                    report = generateMonthlySummary(startDate, endDate);
                    break;
            }
            reportOutput.setText(report);
        } catch (Exception e) {
            showAlert("Error", "Failed to generate report: " + e.getMessage());
        }
    }

    @FXML
    private void handleExportReport() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Report");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("CSV Files", "*.csv")
        );

        File file = fileChooser.showSaveDialog(null);
        if (file != null) {
            try {
                LocalDate startDate = startDatePicker.getValue();
                LocalDate endDate = endDatePicker.getValue();
                String reportType = reportTypeComboBox.getValue();

                CSVExporter.exportReport(
                        reportType,
                        startDate,
                        endDate,
                        file.getAbsolutePath()
                );

                showAlert("Success", "Report exported successfully to " + file.getPath());
            } catch (Exception e) {
                showAlert("Error", "Failed to export report: " + e.getMessage());
            }
        }
    }

    private String generateDetailedReport(LocalDate startDate, LocalDate endDate) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("Detailed Expenses Report\n");
        sb.append("Date Range: ").append(startDate).append(" to ").append(endDate).append("\n\n");
        sb.append("Date\t\tAmount\tCategory\tDescription\n");

        List<Expense> expenses = expenseDAO.getExpensesByDateRange(startDate, endDate);
        for (Expense expense : expenses) {
            sb.append(expense.getDate()).append("\t")
                    .append(expense.getAmount()).append("\t")
                    .append(expense.getCategoryName()).append("\t")
                    .append(expense.getDescription()).append("\n");
        }

        sb.append("\nTotal Expenses: ").append(expenses.stream().mapToDouble(Expense::getAmount).sum());
        return sb.toString();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
