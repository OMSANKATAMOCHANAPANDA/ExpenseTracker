// DashboardController.java
package com.expensetracker.controllers;

import com.expensetracker.database.ExpenseDAO;
import com.expensetracker.models.Expense;
import com.expensetracker.utils.ChartGenerator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {
    @FXML private BarChart<String, Number> monthlyChart;
    @FXML private PieChart categoryChart;
    @FXML private TableView<Expense> recentExpensesTable;
    @FXML private TableColumn<Expense, String> dateColumn;
    @FXML private TableColumn<Expense, String> amountColumn;
    @FXML private TableColumn<Expense, String> categoryColumn;
    @FXML private TableColumn<Expense, String> descriptionColumn;

    private final ExpenseDAO expenseDAO = new ExpenseDAO();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupTableColumns();
        refreshData();
    }

    private void setupTableColumns() {
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("formattedDate"));
        amountColumn.setCellValueFactory(new PropertyValueFactory<>("formattedAmount"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("categoryName"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
    }

    public void refreshData() {
        try {
            LocalDate today = LocalDate.now();
            LocalDate firstDayOfMonth = today.withDayOfMonth(1);

            // Load recent expenses
            List<Expense> expenses = expenseDAO.getExpensesByDateRange(firstDayOfMonth, today);
            ObservableList<Expense> expenseData = FXCollections.observableArrayList(expenses);
            recentExpensesTable.setItems(expenseData);

            // Generate charts
            ChartGenerator.generateMonthlyBarChart(monthlyChart, firstDayOfMonth, today);
            ChartGenerator.generateCategoryPieChart(categoryChart, firstDayOfMonth, today);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
