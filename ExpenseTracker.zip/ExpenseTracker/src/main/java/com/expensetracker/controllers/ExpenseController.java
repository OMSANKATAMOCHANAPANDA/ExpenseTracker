// ExpenseFormController.java
package com.expensetracker.controllers;

import com.expensetracker.database.CategoryDAO;
import com.expensetracker.database.ExpenseDAO;
import com.expensetracker.models.Category;
import com.expensetracker.models.Expense;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.SQLException;
import java.time.LocalDate;

public class ExpenseFormController {
    @FXML private TextField amountField;
    @FXML private ComboBox<Category> categoryComboBox;
    @FXML private DatePicker datePicker;
    @FXML private TextArea descriptionArea;
    @FXML private Label statusLabel;

    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final ExpenseDAO expenseDAO = new ExpenseDAO();

    public void initialize() {
        loadCategories();
        datePicker.setValue(LocalDate.now());
    }

    private void loadCategories() {
        try {
            categoryComboBox.getItems().setAll(categoryDAO.getAllCategories());
            if (!categoryComboBox.getItems().isEmpty()) {
                categoryComboBox.getSelectionModel().selectFirst();
            }
        } catch (SQLException e) {
            showError("Failed to load categories: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddExpense() {
        try {
            Expense expense = new Expense();
            expense.setAmount(Double.parseDouble(amountField.getText()));
            expense.setCategoryId(categoryComboBox.getValue().getId());
            expense.setDate(datePicker.getValue());
            expense.setDescription(descriptionArea.getText());

            expenseDAO.addExpense(expense);

            clearForm();
            statusLabel.setText("Expense added successfully!");
        } catch (NumberFormatException e) {
            showError("Please enter a valid amount");
        } catch (Exception e) {
            showError("Error adding expense: " + e.getMessage());
        }
    }

    private void clearForm() {
        amountField.clear();
        descriptionArea.clear();
        datePicker.setValue(LocalDate.now());
        categoryComboBox.getSelectionModel().selectFirst();
    }

    private void showError(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: red;");
    }
}
