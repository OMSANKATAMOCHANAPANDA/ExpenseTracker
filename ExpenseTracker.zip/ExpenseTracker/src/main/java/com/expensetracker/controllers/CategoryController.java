package com.expensetracker.controllers;

import com.expensetracker.database.CategoryDAO;
import com.expensetracker.models.Category;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;
import java.util.Optional;

public class CategoryController {

    @FXML
    private TableView<Category> categoryTable;

    @FXML
    private TableColumn<Category, String> nameColumn;

    @FXML
    private TableColumn<Category, Double> budgetColumn;

    @FXML
    private TextField nameField;

    @FXML
    private TextField budgetField;

    @FXML
    private Label statusLabel;

    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final ObservableList<Category> categories = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Setup table columns
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        budgetColumn.setCellValueFactory(new PropertyValueFactory<>("budgetLimit"));

        // Format budget column to display currency
        budgetColumn.setCellFactory(tc -> new TableCell<Category, Double>() {
            @Override
            protected void updateItem(Double amount, boolean empty) {
                super.updateItem(amount, empty);
                if (empty || amount == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", amount));
                }
            }
        });

        loadCategories();
    }

    private void loadCategories() {
        try {
            categories.setAll(categoryDAO.getAllCategories());
            categoryTable.setItems(categories);
            clearForm();
        } catch (SQLException e) {
            showError("Failed to load categories: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddCategory() {
        if (!validateInput()) {
            return;
        }

        Category category = new Category();
        category.setName(nameField.getText().trim());
        category.setBudgetLimit(Double.parseDouble(budgetField.getText()));

        try {
            categoryDAO.addCategory(category);
            loadCategories();
            showSuccess("Category added successfully!");
        } catch (SQLException e) {
            showError("Failed to add category: " + e.getMessage());
        }
    }

    @FXML
    private void handleEditCategory() {
        Category selected = categoryTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("Please select a category to edit");
            return;
        }

        nameField.setText(selected.getName());
        budgetField.setText(String.valueOf(selected.getBudgetLimit()));
    }

    @FXML
    private void handleUpdateCategory() {
        Category selected = categoryTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("Please select a category to update");
            return;
        }

        if (!validateInput()) {
            return;
        }

        try {
            selected.setName(nameField.getText().trim());
            selected.setBudgetLimit(Double.parseDouble(budgetField.getText()));
            categoryDAO.updateCategory(selected);
            loadCategories();
            showSuccess("Category updated successfully!");
        } catch (SQLException e) {
            showError("Failed to update category: " + e.getMessage());
        }
    }

    @FXML
    private void handleDeleteCategory() {
        Category selected = categoryTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("Please select a category to delete");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Deletion");
        alert.setHeaderText("Delete Category");
        alert.setContentText("Are you sure you want to delete '" + selected.getName() + "'?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                categoryDAO.deleteCategory(selected.getId());
                loadCategories();
                showSuccess("Category deleted successfully!");
            } catch (SQLException e) {
                showError("Failed to delete category: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleClearForm() {
        clearForm();
    }

    private boolean validateInput() {
        if (nameField.getText() == null || nameField.getText().trim().isEmpty()) {
            showError("Category name is required");
            return false;
        }

        try {
            Double.parseDouble(budgetField.getText());
        } catch (NumberFormatException e) {
            showError("Budget must be a valid number");
            return false;
        }

        return true;
    }

    private void clearForm() {
        nameField.clear();
        budgetField.clear();
        statusLabel.setText("");
    }

    private void showError(String message) {
        statusLabel.setStyle("-fx-text-fill: red;");
        statusLabel.setText(message);
    }

    private void showSuccess(String message) {
        statusLabel.setStyle("-fx-text-fill: green;");
        statusLabel.setText(message);
    }
}
