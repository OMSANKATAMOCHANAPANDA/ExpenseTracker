#!/bin/bash

# Expense Tracker Startup Script for Linux/Mac

# Set Java home if not already set
#export JAVA_HOME=/path/to/jdk17

# Check if Maven is installed
if ! command -v mvn &> /dev/null
then
    echo "Maven not found! Trying to run direct from JAR..."
    java -jar target/expense-tracker-*.jar
    exit
fi

# Run the application
echo "Starting Expense Tracker..."
mvn javafx:run

# Alternative to run from built JAR
# java -jar target/expense-tracker-1.0-SNAPSHOT-jar-with-dependencies.jar